<?php

namespace Sitecake\Exception;

class FileNotFoundException extends \RuntimeException {
	
}