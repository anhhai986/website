function Gh(){}
function Ch(){}
function Hh(){Dh=new Gh;Vb((Sb(),Rb),14);!!$stats&&$stats(Dc(sr,er,-1,-1));Dh.r();!!$stats&&$stats(Dc(sr,fr,-1,-1))}
var sr='runCallbacks14';_=Gh.prototype=Ch.prototype=new M;_.r=function Ih(){};_.cM={};var Dh=null;$entry(Hh)();