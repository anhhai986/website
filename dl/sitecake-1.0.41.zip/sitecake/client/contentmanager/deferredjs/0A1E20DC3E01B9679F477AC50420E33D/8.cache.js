function Pi(){}
function Li(){}
function Qi(){Mi=new Pi;Vb((Sb(),Rb),8);!!$stats&&$stats(Dc(mr,er,-1,-1));Mi.r();!!$stats&&$stats(Dc(mr,fr,-1,-1))}
var mr='runCallbacks8';_=Pi.prototype=Li.prototype=new M;_.r=function Ri(){};_.cM={};var Mi=null;$entry(Qi)();