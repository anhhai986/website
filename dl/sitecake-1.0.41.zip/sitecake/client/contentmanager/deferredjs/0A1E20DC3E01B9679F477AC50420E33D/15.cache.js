function Nh(){}
function Jh(){}
function Oh(){Kh=new Nh;Vb((Sb(),Rb),15);!!$stats&&$stats(Dc(tr,er,-1,-1));Kh.r();!!$stats&&$stats(Dc(tr,fr,-1,-1))}
var tr='runCallbacks15';_=Nh.prototype=Jh.prototype=new M;_.r=function Ph(){};_.cM={};var Kh=null;$entry(Oh)();