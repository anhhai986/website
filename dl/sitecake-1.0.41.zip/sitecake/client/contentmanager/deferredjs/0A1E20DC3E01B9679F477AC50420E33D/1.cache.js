function Zg(){}
function Vg(){}
function $g(){Wg=new Zg;Vb((Sb(),Rb),1);!!$stats&&$stats(Dc(dr,er,-1,-1));Wg.r();!!$stats&&$stats(Dc(dr,fr,-1,-1))}
var dr='runCallbacks1';_=Zg.prototype=Vg.prototype=new M;_.r=function _g(){};_.cM={};var Wg=null;$entry($g)();