function lh(){}
function hh(){}
function mh(){ih=new lh;Vb((Sb(),Rb),11);!!$stats&&$stats(Dc(pr,er,-1,-1));ih.r();!!$stats&&$stats(Dc(pr,fr,-1,-1))}
var pr='runCallbacks11';_=lh.prototype=hh.prototype=new M;_.r=function nh(){};_.cM={};var ih=null;$entry(mh)();