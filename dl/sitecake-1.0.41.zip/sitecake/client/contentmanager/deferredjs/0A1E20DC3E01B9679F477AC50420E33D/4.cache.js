function ni(){}
function ji(){}
function oi(){ki=new ni;Vb((Sb(),Rb),4);!!$stats&&$stats(Dc(ir,er,-1,-1));ki.r();!!$stats&&$stats(Dc(ir,fr,-1,-1))}
var ir='runCallbacks4';_=ni.prototype=ji.prototype=new M;_.r=function pi(){};_.cM={};var ki=null;$entry(oi)();