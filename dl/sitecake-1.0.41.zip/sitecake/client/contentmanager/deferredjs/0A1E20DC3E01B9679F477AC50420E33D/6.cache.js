function Bi(){}
function xi(){}
function Ci(){yi=new Bi;Vb((Sb(),Rb),6);!!$stats&&$stats(Dc(kr,er,-1,-1));yi.r();!!$stats&&$stats(Dc(kr,fr,-1,-1))}
var kr='runCallbacks6';_=Bi.prototype=xi.prototype=new M;_.r=function Di(){};_.cM={};var yi=null;$entry(Ci)();