function Wi(){}
function Si(){}
function Xi(){Ti=new Wi;Vb((Sb(),Rb),9);!!$stats&&$stats(Dc(nr,er,-1,-1));Ti.r();!!$stats&&$stats(Dc(nr,fr,-1,-1))}
var nr='runCallbacks9';_=Wi.prototype=Si.prototype=new M;_.r=function Yi(){};_.cM={};var Ti=null;$entry(Xi)();