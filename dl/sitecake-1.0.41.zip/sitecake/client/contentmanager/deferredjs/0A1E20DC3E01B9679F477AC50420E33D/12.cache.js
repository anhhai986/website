function sh(){}
function oh(){}
function th(){ph=new sh;Vb((Sb(),Rb),12);!!$stats&&$stats(Dc(qr,er,-1,-1));ph.r();!!$stats&&$stats(Dc(qr,fr,-1,-1))}
var qr='runCallbacks12';_=sh.prototype=oh.prototype=new M;_.r=function uh(){};_.cM={};var ph=null;$entry(th)();