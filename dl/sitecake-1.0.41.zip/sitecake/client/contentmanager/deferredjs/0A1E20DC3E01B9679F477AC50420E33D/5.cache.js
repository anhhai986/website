function ui(){}
function qi(){}
function vi(){ri=new ui;Vb((Sb(),Rb),5);!!$stats&&$stats(Dc(jr,er,-1,-1));ri.r();!!$stats&&$stats(Dc(jr,fr,-1,-1))}
var jr='runCallbacks5';_=ui.prototype=qi.prototype=new M;_.r=function wi(){};_.cM={};var ri=null;$entry(vi)();