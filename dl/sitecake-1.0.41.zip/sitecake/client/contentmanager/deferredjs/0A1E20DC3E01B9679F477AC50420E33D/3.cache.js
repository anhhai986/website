function gi(){}
function ci(){}
function hi(){di=new gi;Vb((Sb(),Rb),3);!!$stats&&$stats(Dc(hr,er,-1,-1));di.r();!!$stats&&$stats(Dc(hr,fr,-1,-1))}
var hr='runCallbacks3';_=gi.prototype=ci.prototype=new M;_.r=function ii(){};_.cM={};var di=null;$entry(hi)();