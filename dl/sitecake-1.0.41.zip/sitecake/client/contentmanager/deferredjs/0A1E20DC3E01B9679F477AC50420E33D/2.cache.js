function _h(){}
function Xh(){}
function ai(){Yh=new _h;Vb((Sb(),Rb),2);!!$stats&&$stats(Dc(gr,er,-1,-1));Yh.r();!!$stats&&$stats(Dc(gr,fr,-1,-1))}
var gr='runCallbacks2';_=_h.prototype=Xh.prototype=new M;_.r=function bi(){};_.cM={};var Yh=null;$entry(ai)();