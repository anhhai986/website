function Ii(){}
function Ei(){}
function Ji(){Fi=new Ii;Vb((Sb(),Rb),7);!!$stats&&$stats(Dc(lr,er,-1,-1));Fi.r();!!$stats&&$stats(Dc(lr,fr,-1,-1))}
var lr='runCallbacks7';_=Ii.prototype=Ei.prototype=new M;_.r=function Ki(){};_.cM={};var Fi=null;$entry(Ji)();