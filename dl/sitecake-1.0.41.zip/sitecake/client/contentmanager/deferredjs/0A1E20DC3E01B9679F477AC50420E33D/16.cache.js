function Uh(){}
function Qh(){}
function Vh(){Rh=new Uh;Vb((Sb(),Rb),16);!!$stats&&$stats(Dc(ur,er,-1,-1));Rh.r();!!$stats&&$stats(Dc(ur,fr,-1,-1))}
var ur='runCallbacks16';_=Uh.prototype=Qh.prototype=new M;_.r=function Wh(){};_.cM={};var Rh=null;$entry(Vh)();