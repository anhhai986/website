function eh(){}
function ah(){}
function fh(){bh=new eh;Vb((Sb(),Rb),10);!!$stats&&$stats(Dc(or,er,-1,-1));bh.r();!!$stats&&$stats(Dc(or,fr,-1,-1))}
var or='runCallbacks10';_=eh.prototype=ah.prototype=new M;_.r=function gh(){};_.cM={};var bh=null;$entry(fh)();