<?php

require_once 'simple_html_dom.php';

class SimpleHtmlDom_Node extends simple_html_dom_node
{
}