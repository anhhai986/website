Installation instructions and documentation could be found on
http://sitecake.com/install.html